class bar():
    def __init__(this, prop : dict) -> None:
        this.props = prop
        print(this.value)
        
    def setValue(this, value):
        this.value = value
        print(this.value)
    
    @property
    def props(this):
        return this._props
    
    @props.setter
    def props(this, value : dict):
        this._props = value
    
    @property
    def value(this):
        return this._props['value']
    @value.setter
    def value(this, value):
        this._props['value'] = value
    
foo = bar({'value': 'test'})
print(foo.value)
print(foo.props)
foo.setValue('hello')
print(foo.value)
print(foo.props)
