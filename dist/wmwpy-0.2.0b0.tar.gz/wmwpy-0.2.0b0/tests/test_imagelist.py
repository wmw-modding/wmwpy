import wmwpy

game = 'game/wmp-restoration'

imagelist = wmwpy.Utils.ImageUtils.Imagelist(game, '/assets', '/Perry/Textures/Carl.imagelist')

print(imagelist)
