import sys
import os
sys.path.insert(0, os.path.abspath('src'))

import wmwpy
import timeit

gamepath = 'game/wmw-1.18.7-mod'
assets = '/assets'

def v0():
    files = wmwpy.Utils.filesystem.Filesystem(gamepath, assets)
    start = timeit.default_timer()
    files.getAssets_v0()
    end = timeit.default_timer()

    return end - start

def v1():
    files = wmwpy.Utils.filesystem.Filesystem(gamepath, assets)
    start = timeit.default_timer()
    files.getAssets()
    end = timeit.default_timer()

    return end - start

results = {
    'v0': 0,
    'v1': 0,
}

print('v0:')
results['v0'] = v0()
print('v1:')
results['v1'] = v1()

print(f'\nv0: {str(results["v0"])}\nv1: {str(results["v1"])}')
