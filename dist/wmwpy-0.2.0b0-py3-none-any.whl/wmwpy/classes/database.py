import sqlite3

from ..gameobject import GameObject
from ..Utils.filesystem import *

class Database(GameObject):
    def __init__(
        this,
        database : str | bytes | File,
        filesystem: Filesystem | Folder = None,
        gamepath: str = None,
        assets: str = '/assets',
        baseassets: str = '/',
    ) -> None:
        super().__init__(filesystem, gamepath, assets, baseassets)
        
        file = sqlite3.connect()
