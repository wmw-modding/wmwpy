import wmwpy

game = wmwpy.load('game/wmw-1.18.7-mod', '/assets')
game.generateFileManifest()
