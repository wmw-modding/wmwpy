# wmwpy
 Python module for working with Where's My...? game files.
