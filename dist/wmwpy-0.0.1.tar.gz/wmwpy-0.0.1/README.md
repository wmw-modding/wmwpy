# wmwpy
 Python module for working with Where's My...? game files.

 <!-- Note: using https://packaging.python.org/en/latest/guides/publishing-package-distribution-releases-using-github-actions-ci-cd-workflows/ for distributing.-->

 This is going to be used in Where's My Editor, a level editor for the Where's My...? series.

# Credits
 Thanks to [@campbellsonic](https://github.com/campbellsonic) for the script to read waltex images. I could not have done it without them.
