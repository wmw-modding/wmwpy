# I'm not gonna copy and paste code from wheres-my-editor/GetObject.py because I want to write it better,
# including more things, such as getting more data, and maybe even getting better animations.
