class Layout():
    def __init__(self) -> None:
        pass